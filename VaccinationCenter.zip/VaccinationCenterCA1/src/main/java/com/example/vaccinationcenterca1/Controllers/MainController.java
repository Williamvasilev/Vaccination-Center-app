package com.example.vaccinationcenterca1.Controllers;

public class MainController {
}
